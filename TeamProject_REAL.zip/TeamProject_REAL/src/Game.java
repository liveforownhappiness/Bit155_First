import java.io.Serializable;

public abstract class Game implements Serializable{
	int score1;
	int score2;
	int score3;
	int score4;

	int newScore;
	
	public void scoreAutoSave(int newScore) {

	}

}
