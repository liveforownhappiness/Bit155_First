package bar;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Continuous_Press {
    public static void main(String[] args) {

        try {
            int time = Integer.valueOf(JOptionPane.showInputDialog("제한 시간을 입력하세요"));
            TabAndThreadEx frame = new TabAndThreadEx(time);
        } catch (NumberFormatException e) {
            System.out.println("잘못된 입력입니다. 숫자만 입력해주세요.");
        }

    }
}
